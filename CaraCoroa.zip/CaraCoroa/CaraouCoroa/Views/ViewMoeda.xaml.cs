namespace CaraCoroa.Views;
using CaraCoroa.Models;
using CaraCoroa.ViewModels;

public partial class ViewMoeda : ContentPage
{
    public ViewMoeda()
    {
        InitializeComponent();

        this.BindingContext = new MoedaViewModel();
    }

    private void CoinFlipButton_Clicked(object sender, EventArgs e)
    {
        string ladoEscolhido = Convert.ToString(pickerMoeda.SelectedItem);
        //Jogar a moeda
        Moeda coin = new Moeda();
        string resultado = coin.Jogar(ladoEscolhido);
        //Pegar o resultado da Moeda e escrever na label


        ResultLabel.Text = resultado;
        imagemMoeda.Source = $"{coin.Lado}.png";
    }
}
namespace PedraPapelTesoura.Views;
using PedraPapelTesoura.Models;
using PedraPapelTesoura.ViewModels;

public partial class JogoView : ContentPage
{
	public JogoView()
	{
        InitializeComponent();
	}


    private void Button_Clicked(object sender, EventArgs e)
    {
        string imagemBot = "";
        string imagemPlayer = "";
        string resultado="";
        string escolhaPlayer = Convert.ToString(pickerOp.SelectedItem);
        Jogador bot = new Jogador();
        string escolhaBot = bot.EscolhaBot();
        
        if(escolhaBot == escolhaPlayer)
        {
            resultado = "Empate!";

        }else if(escolhaBot == "pedra" && escolhaPlayer == "papel")
        {
            resultado = "Voce venceu :)";
        }
        else if (escolhaBot == "papel" && escolhaPlayer == "pedra")
        {
            resultado = "Voce Perdeu :(";
        }
        else if (escolhaBot == "tesoura" && escolhaPlayer == "papel")
        {
            resultado = "Voce Perdeu :(";
        }
        else if (escolhaBot == "papel" && escolhaPlayer == "tesoura")
        {
            resultado = "Voce venceu :)";
        }
        else if (escolhaBot == "pedra" && escolhaPlayer == "tesoura")
        {
            resultado = "Voce Perdeu :(";
        }
        else if (escolhaBot == "tesoura" && escolhaPlayer == "pedra")
        {
            resultado = "Voce venceu :)";
        }

        ResultadoLabel.Text = resultado;
        imgBot.Source = $"{escolhaBot}.png";
        imgPlayer.Source = $"{escolhaPlayer}.png";
    }
}
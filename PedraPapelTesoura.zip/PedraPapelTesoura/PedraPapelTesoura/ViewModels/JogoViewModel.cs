﻿using CommunityToolkit.Mvvm.ComponentModel;
using PedraPapelTesoura.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedraPapelTesoura.ViewModels
{
    public partial class GameViewModel : ObservableObject
    {
        [ObservableProperty]
        private string _nome;

        [ObservableProperty]
        private int _score;

        [ObservableProperty]
        private string _playerImage;

        [ObservableProperty]
        private string _enemyImage;

        [ObservableProperty]
        private string _result;

        [ObservableProperty]
        private Escolha _jogadorEscolha;

        Jogador jogador = new Jogador();

        public void Play()
        {
            Jogador enemy = new Jogador();
            enemy.EscolhaBot();
            jogador.Escolha = JogadorEscolha;
            if (enemy.Escolha == jogador.Escolha)
            {
                Result = "Empatou";
            }
        }

        public GameViewModel()
        {

        }
    }
}
﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedraPapelTesoura.Models
{
    public enum Escolha
    {
        pedra,
        papel,
        tesoura
    }
}
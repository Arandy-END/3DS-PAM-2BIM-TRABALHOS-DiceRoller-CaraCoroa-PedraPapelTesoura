﻿using Android.Speech.Tts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PedraPapelTesoura.Models
{
    public class Jogador
    {
        public string Nome { get; set; }
        public int Score { get; set; }
        public Escolha Escolha { get; set; }

        public string EscolhaBot()
        {
            string Escolha = Convert.ToString((Escolha)new Random().Next(3));
            return (Escolha);

        }
    }
}